## Csv file formatting rules

- `email` and `role` must be defined for every member and must be inclided as column names in the first row
- all column names must be in `camelCase`
- roles should be in lowercase and one of the following: `lead`, `tpm`, `pm`, `developer`, `designer`, `business`
- similarly, `subteam` and `formerSubteams` should only contain the following: `idol`, `reviews`, `leads`, `queuemein`, `cuapts`, `courseplan`, `business`, `clubview`, `carriage`, `zing`, `cornellgo`, `dac`
- the current `subteam` should not also be in `formerSubteams`
- any cells with commas should be wrapped inside quotes (Sheets and Excel will automatically do this when converting)
- all empty cells and columns other than those in the sample file will be ignored
